using GTiSolution.Framework.SecurityLayer.Infra.Data.Mappings;
using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Context
{
    public partial class SecurityLayerContext : DbContext
    {  
        public SecurityLayerContext()
            : base(GTiSolution.Framework.DataBase.DataBase.GetConnectionString("cnnSecurityLayer"))
        {
        }
        
        public DbSet<ServiceToken> ServiceTokens { get; set; }
        public DbSet<UserServiceToken> UserServiceTokens { get; set; }
        public DbSet<UserToken> UserTokens { get; set; }
        public DbSet<CorsOrigin> CorsOrigins { get; set; }
        public DbSet<ServiceCorsOrigin> ServiceCorsOrigins { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // Mapeamento das entidades de neg�cio
            modelBuilder.Configurations.Add(new ServiceTokenMap());
            modelBuilder.Configurations.Add(new UserServiceTokenMap());
            modelBuilder.Configurations.Add(new UserTokenMap());
            modelBuilder.Configurations.Add(new CorsOriginMap());
            modelBuilder.Configurations.Add(new ServiceCorsOriginMap());

            base.OnModelCreating(modelBuilder);
        }
    }
}
