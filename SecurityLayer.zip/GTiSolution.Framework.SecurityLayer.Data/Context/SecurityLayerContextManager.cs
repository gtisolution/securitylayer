﻿using GTiSolution.Framework.SecurityLayer.Infra.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Context
{    
    public class SecurityLayerContextManager : IContextManager
    {
        private const string ContextKey = "SecurityLayerContextManager.Context";

        public SecurityLayerContext GetContext()
        {
            var context = HttpContext.Current;
            if (context.Items[ContextKey] == null)
            {
                context.Items[ContextKey] = new SecurityLayerContext();
            }

            return (SecurityLayerContext)context.Items[ContextKey];
        }
    }
}
