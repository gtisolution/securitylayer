﻿using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GTiSolution.Framework.SecurityLayer.Infra.Data.Repository.Dapper;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Repository
{
    public class UserTokenRepository : BaseRepository<UserToken>, IUserTokenRepository
    {   
    }
}
