﻿using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository;
using MicroOrm.Dapper.Repositories;
using MicroOrm.Dapper.Repositories.SqlGenerator;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Repository
{
    public class UserTokenDapper : DapperRepository<UserToken>, IUserTokenDapper
    {
        protected const ESqlConnector SqlConnector = ESqlConnector.MSSQL;
        protected ISqlGenerator<UserToken> userSqlGenerator;
        public UserTokenDapper()
        {
            userSqlGenerator = new SqlGenerator<UserToken>(SqlConnector, true);
        }
        public UserTokenDapper(IDbConnection connection) : base(connection) { }
        public UserTokenDapper(IDbConnection connection, ESqlConnector sqlConnector) : base(connection, sqlConnector) { }
        public UserTokenDapper(IDbConnection connection, ISqlGenerator<UserToken> sqlGenerator) : base(connection, sqlGenerator) { }
        public UserTokenDapper(IDbConnection connection, SqlGeneratorConfig config) : base(connection, config) { }
    }
}
