﻿using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Entities;
using GTiSolution.Framework.SecurityLayer.Infra.Data.Repository.ReadOnly;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Repository
{
    public class CorsOriginRepository : BaseRepository<CorsOrigin>, ICorsOriginRepository
    {
    }
}
