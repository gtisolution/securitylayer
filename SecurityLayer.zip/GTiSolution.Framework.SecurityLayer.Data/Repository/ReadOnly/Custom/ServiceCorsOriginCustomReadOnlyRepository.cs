﻿using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Custom;
using System.Collections.Generic;
using System.Linq;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using Dapper;
using System;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Repository.ReadOnly.Custom
{
    public class ServiceCorsOriginCustomReadOnlyRepository : BaseCustomRepository, IServiceCorsOriginCustomReadOnlyRepository
    {
        public List<OrigemServicoCustomResult> ListarOrigemServicoPorServiceId(string serviceId)
        {
            using (var conn = Connection)
            {
                var sql = "SELECT b.OriginId, b.OriginName, a.Active FROM ServiceCorsOrigin a ";
                sql = string.Concat(sql, "INNER JOIN CorsOrigin b on a.OriginId = b.OriginId ");
                sql = string.Concat(sql, "AND a.ServiceId = @serviceId ");
                
                var param = new { serviceId = serviceId };
                var result = conn.Query<OrigemServicoCustomResult>(sql, param).ToList();

                return result;
            }
        }

        public List<OrigemServicoCustomResult> ListarOrigemServicoPorServiceName(string serviceName)
        {
            using (var conn = Connection)
            {
                var sql = "SELECT c.ServiceId, b.OriginId, b.OriginName, a.Active FROM ServiceCorsOrigin a ";
                sql = string.Concat(sql, "INNER JOIN CorsOrigin b on a.OriginId = b.OriginId ");
                sql = string.Concat(sql, "INNER JOIN ServiceToken c on a.ServiceId = c.ServiceId ");
                sql = string.Concat(sql, "AND c.ServiceName = @serviceName ");

                var param = new { serviceName = serviceName };
                var result = conn.Query<OrigemServicoCustomResult>(sql, param).ToList();

                return result;
            }
        }
    }
}
