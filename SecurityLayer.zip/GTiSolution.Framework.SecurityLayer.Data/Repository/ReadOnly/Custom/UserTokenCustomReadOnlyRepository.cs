﻿using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using System.Data;
using GTiSolution.Framework.SecurityLayer.Infra.Data.Repository.Dapper;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Custom;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Repository.ReadOnly.Custom
{
    public class UserTokenCustomReadOnlyRepository : BaseCustomRepository, IUserTokenCustomReadOnlyRepository
    {
        #region IUserTokenReadOnlyRepository Members

        public UsuarioSecurityResult ObterUsuarioSecurity(string login)
        {
             using (var conn = Connection)
             {
                 var sql = "SELECT ut.UserId CodigoUsuario, ut.PasswordHash, ust.ServiceId CodigoServico, ";
                 sql = string.Concat(sql, "st.ServiceName NomeServico, ust.ExternalLogin LoginExterno, ust.Active ServicoAtivo ");
                 sql = string.Concat(sql, "FROM UserToken ut ");
                 sql = string.Concat(sql, "INNER JOIN UserServiceToken ust ON ut.UserId = ust.UserId ");
                 sql = string.Concat(sql, "INNER JOIN ServiceToken st ON st.ServiceId = ust.ServiceId ");
                 sql = string.Concat(sql, "WHERE ut.Login = @Login ");

                 var param = new { Login = login };
                 var result = conn.QueryParentChild<UsuarioSecurityResult, UsuarioServicoResult, string>(sql, p => p.CodigoUsuario, p => p.Servicos, param, splitOn: "CodigoUsuario, CodigoServico")
                     .FirstOrDefault();

                 return result;            
             }
        }

        public UsuarioResult ObterUsuario(string login)
        {
            using (var conn = Connection)
            {
                var sql = "SELECT ut.UserId CodigoUsuario, ut.Login, ut.UserName NomeUsuario, ust.ServiceId CodigoServico, ";
                sql = string.Concat(sql, "st.ServiceName NomeServico, ust.ExternalLogin LoginExterno, ust.Active ServicoAtivo ");
                sql = string.Concat(sql, "FROM UserToken ut ");
                sql = string.Concat(sql, "INNER JOIN UserServiceToken ust ON ut.UserId = ust.UserId ");
                sql = string.Concat(sql, "INNER JOIN ServiceToken st ON st.ServiceId = ust.ServiceId ");
                sql = string.Concat(sql, "WHERE ut.Login = @Login");

                var param = new { Login = login};
                var result = conn.QueryParentChild<UsuarioResult, UsuarioServicoResult, string>(sql, p => p.CodigoUsuario, p => p.Servicos, param, splitOn: "CodigoUsuario, CodigoServico")
                    .FirstOrDefault();

                return result;
            }
        }

        public IEnumerable<UsuarioResult> ListarUsuarios()
        {
            using (var conn = Connection)
            {
                var sql = "SELECT ut.UserId CodigoUsuario, ut.Login, ut.UserName NomeUsuario, ust.ServiceId CodigoServico, ";
                sql = string.Concat(sql, "st.ServiceName NomeServico, ust.ExternalLogin LoginExterno, ust.Active ServicoAtivo ");
                sql = string.Concat(sql, "FROM UserToken ut ");
                sql = string.Concat(sql, "INNER JOIN UserServiceToken ust ON ut.UserId = ust.UserId ");
                sql = string.Concat(sql, "INNER JOIN ServiceToken st ON st.ServiceId = ust.ServiceId ");
                var result = conn.QueryParentChild<UsuarioResult, UsuarioServicoResult, string>(sql, p => p.CodigoUsuario, p => p.Servicos, splitOn: "CodigoUsuario, CodigoServico")
                    .ToList();

                return result;
            }
        }

        #endregion
    }
}
