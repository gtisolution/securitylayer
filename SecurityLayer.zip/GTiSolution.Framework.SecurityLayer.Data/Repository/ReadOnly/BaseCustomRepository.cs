﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Repository.ReadOnly
{
    public class BaseCustomRepository
    {
        public IDbConnection Connection
        {
            get
            {
                var connectionString = ConfigurationManager.ConnectionStrings["cnnSecurityLayer"].ConnectionString;
                return new SqlConnection(GTiSolution.Framework.Seguranca.Criptografia.Decrypt(connectionString));
            }
        }
    }
}
