﻿using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Repository.ReadOnly.Entities
{
    public class ServiceCorsOriginReadOnlyRepository : BaseReadOnlyRepository<ServiceCorsOrigin>, IServiceCorsOriginReadOnlyRepository
    {
        public ServiceCorsOrigin ObterOrigemServico(string serviceId, string origin)
        {
            throw new NotImplementedException();
        }
    }
}
