﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly;
using MicroOrm.Dapper.Repositories.SqlGenerator;
using Dapper;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Repository.ReadOnly
{
    public class BaseReadOnlyRepository<TEntity> : BaseCustomRepository, IReadOnlyRepository<TEntity> where TEntity : class
    {
        private const ESqlConnector SqlConnector = ESqlConnector.MSSQL;

        #region IReadOnlyRepository<TEntity> Members

        public IEnumerable<TEntity> ListarTodos()
        {
            ISqlGenerator<TEntity> userSqlGenerator = new SqlGenerator<TEntity>(SqlConnector, true);
            var sqlQuery = userSqlGenerator.GetSelectAll(null);

            using (var conn = Connection)
            {
                var result = conn.Query<TEntity>(sqlQuery.GetSql());
                return result;
            }
        }

        public IEnumerable<TEntity> Buscar(System.Linq.Expressions.Expression<Func<TEntity, bool>> predicate)
        {
            
            ISqlGenerator<TEntity> userSqlGenerator = new SqlGenerator<TEntity>(SqlConnector, true);
            var sqlQuery = userSqlGenerator.GetSelectAll(predicate);
            
            using (var conn = Connection)
            {
                var result = conn.Query<TEntity>(sqlQuery.GetSql(), sqlQuery.Param);
                return result;
            }
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {   
            Connection.Dispose();
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
