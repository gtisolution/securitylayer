﻿using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Repository
{
    public class ServiceCorsOriginRepository : BaseRepository<ServiceCorsOrigin>, IServiceCorsOriginRepository
    {
    }
}
