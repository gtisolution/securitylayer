﻿using GTiSolution.Framework.SecurityLayer.Infra.Data.Context;
using GTiSolution.Framework.SecurityLayer.Infra.Data.Interfaces;
using GTiSolution.Framework.SecurityLayer.Data.UoW;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository;
using Microsoft.Practices.ServiceLocation;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;
using System.Data.Common;
using MicroOrm.Dapper.Repositories.SqlGenerator;
using GTiSolution.Framework.SecurityLayer.Infra.Data.Repository.ReadOnly;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Repository
{
    public class BaseRepository<TEntity> : BaseReadOnlyRepository<TEntity>, IRepository<TEntity> where TEntity : class
    {
        protected IDbSet<TEntity> _dbSet;
        protected readonly SecurityLayerContext _context;
        protected readonly SecurityLayerContextManager _contextManager = ServiceLocator.Current.GetInstance<IContextManager>() as SecurityLayerContextManager;

        public BaseRepository()
        {
            _context = _contextManager.GetContext();
            _dbSet = _context.Set<TEntity>();
        }

        #region IRepository<TEntity> Members

        public void Adicionar(TEntity entity)
        {
            _dbSet.Add(entity);
        }

        public TEntity ObterPorId(Guid id)
        {
            return _dbSet.Find(id);
        }

        public IEnumerable<TEntity> ObterTodos()
        {
            return _dbSet.ToList();
        }

        public void Atualizar(TEntity entity)
        {
            var entry = _context.Entry(entity);
            _dbSet.Attach(entity);
            entry.State = EntityState.Modified;
        }

        public void Excluir(TEntity entity)
        {
            _dbSet.Attach(entity);
            _context.Entry(entity).State = EntityState.Deleted;
        }

        public IEnumerable<TEntity> Buscar(System.Linq.Expressions.Expression<Func<TEntity, bool>> predicate)
        {
            return _dbSet.Where(predicate);
        }

        public int SaveChanges()
        {
            return _context.SaveChanges();
        }

        #endregion

        #region IDisposable Members

        public new void Dispose()
        {
            _context.Dispose();
            GC.SuppressFinalize(this);
        }

        #endregion

        static IEnumerable<MemberExpression> GetMemberExpressions(Expression body)
        {
            // A Queue preserves left to right reading order of expressions in the tree
            var candidates = new Queue<Expression>(new[] { body });
            while (candidates.Count > 0)
            {
                var expr = candidates.Dequeue();
                if (expr is MemberExpression)
                {
                    yield return ((MemberExpression)expr);
                }
                else if (expr is UnaryExpression)
                {
                    candidates.Enqueue(((UnaryExpression)expr).Operand);
                }
                else if (expr is BinaryExpression)
                {
                    var binary = expr as BinaryExpression;
                    candidates.Enqueue(binary.Left);
                    candidates.Enqueue(binary.Right);
                }
                else if (expr is MethodCallExpression)
                {
                    var method = expr as MethodCallExpression;
                    foreach (var argument in method.Arguments)
                    {
                        candidates.Enqueue(argument);
                    }
                }
                else if (expr is LambdaExpression)
                {
                    candidates.Enqueue(((LambdaExpression)expr).Body);
                }
            }
        }
    }
}
