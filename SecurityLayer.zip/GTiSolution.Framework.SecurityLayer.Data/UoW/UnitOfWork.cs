﻿using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Uow;
using GTiSolution.Framework.SecurityLayer.Infra.Data.Context;
using GTiSolution.Framework.SecurityLayer.Infra.Data.Interfaces;
using Microsoft.Practices.ServiceLocation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Data.UoW
{
    public class UnitOfWork : IUnitOfWork, IDisposable
    {
        private readonly SecurityLayerContext _context;
        private readonly SecurityLayerContextManager _contextManager = ServiceLocator.Current.GetInstance<IContextManager>() as SecurityLayerContextManager;

        private bool _disposed;

        public UnitOfWork()
        {
            _context = _contextManager.GetContext();
        }

        public void BeginTransaction()
        {
            _disposed = false;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            _disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}
