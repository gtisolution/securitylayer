using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Mappings
{
    public class UserServiceTokenMap : EntityTypeConfiguration<UserServiceToken>
    {
        public UserServiceTokenMap()
        {
            // Primary Key
            this.HasKey(t => new { t.Id, t.UserId, t.ServiceId });

            // Properties
            this.Property(t => t.UserId)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.ServiceId)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.ExternalLogin);

            this.Property(t => t.Active)
                .IsRequired()
                .HasMaxLength(1);

            // Table & Column Mappings
            this.ToTable("UserServiceToken");
            this.Property(t => t.UserId).HasColumnName("UserId");
            this.Property(t => t.ServiceId).HasColumnName("ServiceId");
            this.Property(t => t.ExternalLogin).HasColumnName("ExternalLogin");
            this.Property(t => t.Active).HasColumnName("Active");

            // Relationships
            this.HasRequired(t => t.ServiceToken)
                .WithMany(t => t.UserServiceTokens)
                .HasForeignKey(d => d.ServiceId);
            this.HasRequired(t => t.UserToken)
                .WithMany(t => t.UserServiceTokens)
                .HasForeignKey(d => d.UserId);

        }
    }
}
