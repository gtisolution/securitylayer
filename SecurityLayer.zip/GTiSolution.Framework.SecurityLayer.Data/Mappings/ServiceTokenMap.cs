using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Mappings
{
    public class ServiceTokenMap : EntityTypeConfiguration<ServiceToken>
    {
        public ServiceTokenMap()
        {
            // Primary Key
            this.HasKey(t => t.ServiceId);

            // Properties
            this.Property(t => t.ServiceId)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.ServiceName)
                .IsRequired()
                .HasMaxLength(60);

            // Table & Column Mappings
            this.ToTable("ServiceToken");
            this.Property(t => t.ServiceId).HasColumnName("ServiceId");
            this.Property(t => t.ServiceName).HasColumnName("ServiceName");
        }
    }
}
