using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Mappings
{
    public class UserTokenMap : EntityTypeConfiguration<UserToken>
    {
        public UserTokenMap()
        {
            // Primary Key
            this.HasKey(t => t.UserId);

            // Properties
            this.Property(t => t.UserId)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.Login)
                .IsRequired()
                .HasMaxLength(32);

            this.Property(t => t.PasswordHash)
               .IsRequired();

            this.Property(t => t.UserName)
                .IsRequired()
                .HasMaxLength(60);


            // Table & Column Mappings
            this.ToTable("UserToken");
            this.Property(t => t.UserId).HasColumnName("UserId");
            this.Property(t => t.Login).HasColumnName("Login");
            this.Property(t => t.UserName).HasColumnName("UserName");
            this.Property(t => t.PasswordHash).HasColumnName("PasswordHash");
        }
    }
}
