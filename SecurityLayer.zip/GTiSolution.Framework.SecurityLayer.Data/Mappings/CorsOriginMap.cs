﻿using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Infra.Data.Mappings
{
    public class CorsOriginMap : EntityTypeConfiguration<CorsOrigin>
    {
        public CorsOriginMap()
        {
            // Primary Key
            this.HasKey(t => t.OriginId);

            // Properties            
            this.Property(t => t.OriginName)
               .IsRequired()
               .HasMaxLength(256);
            
            // Table & Column Mappings
            this.ToTable("CorsOrigin");
            this.Property(t => t.OriginId).HasColumnName("OriginId");
            this.Property(t => t.OriginName).HasColumnName("OriginName");            
        }
    }
}
