﻿using GTiSolution.Framework.OAuth2Token.Response;
using Microsoft.Owin.Security.OAuth;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using GTiSolution.Framework.OAuth2Token;
using Microsoft.Owin.Security;

namespace GTiSolution.Framework.OAuth2Token.Credentials
{
    public class UserCredential
    {
        private IRestResponse<UsuarioSecurityResult> _Response;
        
        private void Execute(string login, string password)
        {
            if (_Response == null)
            {                
                var client = new RestClient(ConfigurationManager.AppSettings["ValidacaoUsuario"]);
                var request = new RestRequest("/{login}/{password}", Method.GET);
                request.AddParameter("login", login);
                request.AddParameter("password", password);
                _Response = client.Execute<UsuarioSecurityResult>(request);

                client.EnsureResponseWasSuccessfull(request, _Response);                
            }
        }

        public Dictionary<string, string> Validate(OAuthGrantResourceOwnerCredentialsContext context)
        {
            Dictionary<string, string> validateResult = new Dictionary<string,string>();

            Execute(context.Request.Headers["login"], context.Request.Headers["password"]);
            if (!string.IsNullOrWhiteSpace(_Response.Data.Mensagem))
                validateResult.Add("login_invalido", _Response.Data.Mensagem);            
            
            return validateResult;
        }        

        public ClaimsIdentity GetClaims(OAuthGrantResourceOwnerCredentialsContext context)
        {

            ClaimsIdentity claimsIdentity = new ClaimsIdentity(OAuthDefaults.AuthenticationType);
            if (_Response.Data.Servicos.Any())
            {
                List<Claim> claims = new List<Claim>();
                _Response.Data.Servicos.ForEach(a => 
                { 
                    claims.Add(new Claim(ClaimTypes.Role, a.NomeServico));
                    claims.Add(new Claim("ExternalLogin", a.LoginExterno)); 
                });
                claimsIdentity.AddClaims(claims);
            }

            return claimsIdentity;
        }
    }
}