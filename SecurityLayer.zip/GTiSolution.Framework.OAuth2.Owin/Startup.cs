﻿using GTiSolution.Framework.OAuth2Token.Providers;
using Microsoft.Owin;
using Microsoft.Owin.Security.OAuth;
using Owin;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Http;

[assembly: OwinStartup(typeof(GTiSolution.Framework.OAuth2Token.Startup))]
namespace GTiSolution.Framework.OAuth2Token
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {   

            ConfigureOAuth(app);
            HttpConfiguration config = new HttpConfiguration();            
            config.MapHttpAttributeRoutes();
            app.UseWebApi(config);
            
            app.UseCors(Microsoft.Owin.Cors.CorsOptions.AllowAll);            
        }

        public void ConfigureOAuth(IAppBuilder app)
        {
            OAuthAuthorizationServerOptions OAuthServerOptions = new OAuthAuthorizationServerOptions()
            {   
                AllowInsecureHttp = Convert.ToBoolean(ConfigurationManager.AppSettings["AllowInsecureHttp"]),
                TokenEndpointPath = new PathString(ConfigurationManager.AppSettings["TokenPathString"]),
                AccessTokenExpireTimeSpan = TimeSpan.FromMinutes(Convert.ToInt32(ConfigurationManager.AppSettings["ExpirationTokenMinutes"])),
                Provider = new CustomOAuthProvider()
            };

            // geração do token de acesso OAuth 2.0 Bearer 
            app.UseOAuthAuthorizationServer(OAuthServerOptions);

        }
    }
}