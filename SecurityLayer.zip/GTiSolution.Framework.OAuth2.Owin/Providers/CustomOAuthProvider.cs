﻿using GTiSolution.Framework.OAuth2Token.Credentials;
using GTiSolution.Framework.OAuth2Token.Response;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.OAuth;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;

namespace GTiSolution.Framework.OAuth2Token.Providers
{
    public class CustomOAuthProvider : OAuthAuthorizationServerProvider
    {
        public override Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            if (string.IsNullOrEmpty(context.Request.Headers["Login"]))
            {
                context.SetError("login_invalido", "Obrigatório informar o login");
                return Task.FromResult<object>(null);
            }

            if (string.IsNullOrEmpty(context.Request.Headers["Password"]))
            {
                context.SetError("senha_invalida", "obrigatório informar a senha");
                return Task.FromResult<object>(null);
            }
            
            context.Validated();
            return Task.FromResult<object>(null);
        }

        public override Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
        {
            context.OwinContext.Response.Headers.Add("Access-Control-Allow-Origin", new[] { "*" });

            UserCredential userCredential = new UserCredential();
            Dictionary<string, string> resultValidate = new Dictionary<string, string>();
            
            resultValidate = userCredential.Validate(context);           
            if (resultValidate.Any())
            {
                context.SetError(resultValidate.First().Key, resultValidate.First().Value);
                return Task.FromResult<object>(null);
            }

            ClaimsIdentity claimsIdentity = userCredential.GetClaims(context);
            var ticket = new AuthenticationTicket(claimsIdentity, null);

            context.Validated(ticket);
            return Task.FromResult<object>(null);
        }
    }
}