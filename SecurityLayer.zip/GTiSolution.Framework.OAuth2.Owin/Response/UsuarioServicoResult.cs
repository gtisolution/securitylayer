﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.OAuth2Token.Response
{
    public class UsuarioServicoResult
    {
        public string NomeServico { get; set; }
        public string LoginExterno { get; set; }
    }
}
