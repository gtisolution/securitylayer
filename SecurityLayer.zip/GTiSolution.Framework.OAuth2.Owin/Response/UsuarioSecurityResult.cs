﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.OAuth2Token.Response
{
    public class UsuarioSecurityResult
    {
        public UsuarioSecurityResult()
        {
            Servicos = new List<UsuarioServicoResult>();
        }

        public string Mensagem { get; set; }

        public List<UsuarioServicoResult> Servicos { get; set; }
    }
}
