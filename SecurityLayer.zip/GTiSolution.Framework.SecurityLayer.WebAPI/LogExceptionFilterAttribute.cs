﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Filters;

namespace GTiSolution.Framework.SecurityLayer.WebAPI
{
    public class LogExceptionFilterAttribute : ExceptionFilterAttribute
    {
        public override void OnException(HttpActionExecutedContext context)
        {
            System.Diagnostics.Trace.TraceError(context.Exception.ToString());
            base.OnException(context);
        }
    }
}