﻿using AutoMapper;
using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Services;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Request;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace GTiSolution.Framework.SecurityLayer.WebAPI.Controllers
{
    [RoutePrefix("api/origem")]
    public class OrigemController : ApiController
    {
        private readonly ICorsOriginService _corsOriginService;
        private readonly ICorsOriginReadOnlyRepository _corsOriginReadOnlyRepository;

        public OrigemController(ICorsOriginService corsOriginService,
            ICorsOriginReadOnlyRepository corsOriginReadOnlyRepository)
        {
            _corsOriginService = corsOriginService;
            _corsOriginReadOnlyRepository = corsOriginReadOnlyRepository;
        }

        /// <summary>
        /// Atualizar uma origem já cadastrada
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [Route("atualizar-origem")]
        public IHttpActionResult Post(CorsOriginRequest request)
        {
            return Ok(_corsOriginService.AtualizarOrigem(request));
        }

        /// <summary>
        /// Obter a lista de todas as origens cadastradas
        /// </summary>
        /// <returns></returns>
        [Route("listar-origens")]
        public IEnumerable<CorsOriginResult> Get()
        {
            var result = _corsOriginReadOnlyRepository.ListarTodos();

            var config = new MapperConfiguration(cfg => cfg.CreateMap<CorsOrigin, CorsOriginResult>()
                .ForMember(dest => dest.OriginId, opt => opt.MapFrom("OriginId"))
                .ForMember(dest => dest.OriginName, opt => opt.MapFrom("OriginName")));
            var mapper = new Mapper(config);
            var ret = mapper.DefaultContext.Mapper.Map<List<CorsOriginResult>>(result.ToList()) as List<CorsOriginResult>;

            return ret;
        }
    }
}
