﻿using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Custom;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Services;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace GTiSolution.Framework.SecurityLayer.WebAPI.Controllers
{   
    [RoutePrefix("api/origemservico")]
    public class OrigemServicoController : ApiController
    {
        private readonly IServiceCorsOriginService _serviceCorsOriginService;
        private readonly IServiceCorsOriginCustomReadOnlyRepository _serviceCorsOriginCustomReadOnlyRepository;

        public OrigemServicoController(IServiceCorsOriginService serviceCorsOriginService,
            IServiceCorsOriginCustomReadOnlyRepository serviceCorsOriginCustomReadOnlyRepository)
        {
            _serviceCorsOriginService = serviceCorsOriginService;
            _serviceCorsOriginCustomReadOnlyRepository = serviceCorsOriginCustomReadOnlyRepository;
        }
        /// <summary>
        /// Cadastrar os domínios que estão autorizados a consumir a API
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("nova-origem")]
        public IHttpActionResult Post(ServiceCorsOriginRequest request)
        {
            var novaOrigem = _serviceCorsOriginService.NovaOrigemServico(request);
            return Ok(novaOrigem);
        }

        /// <summary>
        /// Listar origens vinculadas a um deternimado serviço
        /// </summary>
        /// <param name="serviceName"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("listar-servico-origem/{serviceName}")]
        public IHttpActionResult Get(string serviceName)
        {
            var result = _serviceCorsOriginCustomReadOnlyRepository.ListarOrigemServicoPorServiceName(serviceName);
            return Ok(result);
        }

        /// <summary>
        /// Desativar o acesso de uma origem a um serviço específico
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Resultado do processamento</returns>
        [HttpPut]
        [Route("desativar-origem-servico")]
        public IHttpActionResult Desativar(ServiceCorsOriginUpdateRequest request)
        {
            var result = _serviceCorsOriginService.DesativarOrigemServico(request);
            return Ok(result);
        }

        /// <summary>
        /// Reativar o acesso de uma origem a um serviço específico
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Resultado do processamento</returns>
        [HttpPut]
        [Route("reativar-origem-servico")]
        public IHttpActionResult Reativar(ServiceCorsOriginUpdateRequest request)
        {
            var result = _serviceCorsOriginService.ReativarOrigemServico(request);
            return Ok(result);
        }
    }
}
