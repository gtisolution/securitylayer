﻿using AutoMapper;
using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Custom;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Services;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Request;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace GTiSolution.Framework.SecurityLayer.WebAPI.Controllers
{    
    /// <summary>
    /// API para gerenciamento dos usuários
    /// </summary>
    [RoutePrefix("api/usuario")]    
    public class UsuarioController : ApiController
    {
        private readonly IUsuarioService _usuarioService;
        private readonly IVinculoUsuarioService _vinculoUsuarioService;
        private readonly IUsuarioSecurityService _usuarioSecurityService;
        private readonly IUserTokenRepository _userTokenRepository;
        private readonly IUserTokenCustomReadOnlyRepository _userTokenCustomReadOnlyRepository;
        private readonly IUsuarioServicoService _usuarioServicoService;        
        private readonly IServiceCorsOriginService _serviceCorsOriginService;

        public UsuarioController(IUsuarioService usuarioService,
            IVinculoUsuarioService vinculoUsuarioService,
            IUsuarioSecurityService usuarioSecurityService,
            IUserTokenRepository userTokenRepository,
            IUserTokenCustomReadOnlyRepository userTokenCustomReadOnlyRepository,
            IUsuarioServicoService usuarioServicoService,
            IServiceTokenReadOnlyRepository serviceTokenReadOnlyRepository,
            IServiceCorsOriginService serviceCorsOriginService)
        {
            _usuarioService = usuarioService;
            _vinculoUsuarioService = vinculoUsuarioService;
            _usuarioSecurityService = usuarioSecurityService;
            _userTokenRepository = userTokenRepository;
            _userTokenCustomReadOnlyRepository = userTokenCustomReadOnlyRepository;
            _usuarioServicoService = usuarioServicoService;
            _serviceCorsOriginService = serviceCorsOriginService;
        }

        #region HttpPost Methods

        /// <summary>
        /// Criar um novo usuário
        /// </summary>
        ///<remarks>Permite a criação de um usuário novo com acesso a um serviço existente ou não. Se o serviço informado não existir, 
        ///o mesmo será criado para que o usuário possa esse vinculado a ele.</remarks>
        /// <returns></returns>
        [HttpPost]
        [Route("novo-usuario")]
        public IHttpActionResult CriarUsuario(NovoUsuarioRequest usuario)
        {
            var novoUsuario = _usuarioService.CriarUsuario(usuario);
            return Ok(novoUsuario);
        }

        /// <summary>
        /// Vincular usuário a um serviço
        /// </summary>        
        /// <remarks>Permite que um usuário já cadastrado seja vinculado a um serviço também já cadastrado.</remarks>
        /// <returns></returns>
        [HttpPut]
        [Route("vincular-usuario")]
        public IHttpActionResult VincularUsuario(VinculoUsuarioServicoRequest vinculoUsuarioServicoRequest)
        {
            var result = _vinculoUsuarioService.VincularUsuarioServico(vinculoUsuarioServicoRequest);
            return Ok(result);
        }

        /// <summary>
        /// Desativar um usuário
        /// </summary>
        /// <param name="usuarioServicoRequest"></param>
        /// <remarks>Permite a desativação de um usuário, fazendo com que ele não possa mais gerar tonkes de autorização.</remarks>
        /// <returns></returns>
        [HttpPut]
        [Route("desativar-usuario")]
        public IHttpActionResult DesativarUsuario(UsuarioServicoRequest usuarioServicoRequest)
        {
            var result = _usuarioServicoService.DesativarUsuario(usuarioServicoRequest);
            return Ok(result);
        }
        
        #endregion

        #region HttpGet Methods

        /// <summary>
        /// Validar usuário
        /// </summary>
        /// <param name="login">Login do usuário</param>
        /// <param name="password">Senha do usuário</param>
        /// <remarks>Efetua a validação das credenciais do usuário. Utilizado na geração do token de autorização.</remarks>
        /// <returns></returns>
        [HttpGet]
        [Route("validar-usuario/{login}/{password}")]
        public IHttpActionResult ValidarUsuario(string login, string password)
        {
            var result = _usuarioSecurityService.ValidarUsuario(login, password);
            return Ok(result);
        }


        /// <summary>
        /// Obter os dados do usuário
        /// </summary>
        /// <param name="login">Login do usuário</param>
        /// <remarks>Recupera os dados do usuário com os respectivos serviços, dos quais o mesmo tem acesso.</remarks>
        /// <returns></returns>
        [HttpGet]
        [Route("obter-usuario/{login}")]
        public IHttpActionResult ObterUsuarioPorLogin(string login)
        {
            var result = _userTokenCustomReadOnlyRepository.ObterUsuario(login);
            return Ok(result);
        }

        /// <summary>
        /// Obter a lista de todos os usuários
        /// </summary>
        /// <remarks>Recupera a lista de todos os usuários cadastrados, com os respectivos serviços dos quais os mesmos têm acesso.</remarks>
        /// <returns></returns>
        [HttpGet]
        [Route("listar-usuarios")]
        public  IEnumerable<UsuarioResult> ListarUsuarios()
        {
            var result = _userTokenCustomReadOnlyRepository.ListarUsuarios();
            return result;
        }

        

        #endregion
    }
}
