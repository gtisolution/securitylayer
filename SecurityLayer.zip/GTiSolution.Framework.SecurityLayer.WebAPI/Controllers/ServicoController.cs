﻿using AutoMapper;
using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace GTiSolution.Framework.SecurityLayer.WebAPI.Controllers
{
    public class ServicoController : ApiController
    {
        private readonly IServiceTokenReadOnlyRepository _serviceTokenReadOnlyRepository;

        public ServicoController(IServiceTokenReadOnlyRepository serviceTokenReadOnlyRepository)
        {
            _serviceTokenReadOnlyRepository = serviceTokenReadOnlyRepository;
        }
        /// <summary>
        /// Obter a lista de todos os serviços
        /// </summary>
        /// <remarks>Recupera a lista de todos os serviços cadastrados</remarks>
        /// <returns></returns>
        [HttpGet]
        [Route("listar-servicos")]
        public IEnumerable<ServicoResult> ListarServicos()
        {
            var result = _serviceTokenReadOnlyRepository.ListarTodos();

            var config = new MapperConfiguration(cfg => cfg.CreateMap<ServiceToken, ServicoResult>()
                .ForMember(dest => dest.CodigoServico, opt => opt.MapFrom("ServiceId"))
                .ForMember(dest => dest.NomeServico, opt => opt.MapFrom("ServiceName")));
            var mapper = new Mapper(config);
            var ret = mapper.DefaultContext.Mapper.Map<List<ServicoResult>>(result.ToList()) as List<ServicoResult>;

            return ret;
        }
    }
}
