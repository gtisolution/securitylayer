﻿using GTiSolution.Framework.SecurityLayer.Criptografia.Interfaces;
using GTiSolution.Framework.SecurityLayer.Criptografia.Services;
using GTiSolution.Framework.SecurityLayer.Data.UoW;
using GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.DomainServices;
using GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.Interfaces.DomainServices;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Custom;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Services;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Uow;
using GTiSolution.Framework.SecurityLayer.Domain.Services;
using GTiSolution.Framework.SecurityLayer.Infra.Data.Context;
using GTiSolution.Framework.SecurityLayer.Infra.Data.Interfaces;
using GTiSolution.Framework.SecurityLayer.Infra.Data.Repository;
using GTiSolution.Framework.SecurityLayer.Infra.Data.Repository.ReadOnly;
using GTiSolution.Framework.SecurityLayer.Infra.Data.Repository.ReadOnly.Custom;
using GTiSolution.Framework.SecurityLayer.Infra.Data.Repository.ReadOnly.Entities;
using Ninject;
using Ninject.Modules;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Infra.CrossCutting.IOC
{
    public class NinjectModulo : NinjectModule
    {
        public override void Load()
        {   
            // SERVICES
            Bind<IUsuarioService>().To<UsuarioService>();
            Bind<IUsuarioSecurityService>().To<UsuarioSecurityService>();
            Bind<IVinculoUsuarioService>().To<VinculoUsuarioService>();
            Bind<IUsuarioServicoService>().To<UsuarioServicoService>();
            Bind<IServiceCorsOriginService>().To<ServiceCorsOriginService>();

            // CRIPTOGRAFIA
            Bind<ICriptografiaService>().To<CriptografiaService>();

            // DOMAIN SERVICES
            Bind<IUsuarioDomainService>().To<UsuarioDomainService>();
            Bind<IServicoDomainService>().To<ServicoDomainService>();
            Bind<IUsuarioServicoDomainService>().To<UsuarioServicoDomainService>();
            Bind<ICorsOriginService>().To<CorsOriginService>();

            // REPOSITORY (Add, Update and Delete)
            Bind(typeof(IRepository<>)).To(typeof(BaseRepository<>));
            Bind<IUserTokenRepository>().To<UserTokenRepository>();
            Bind<IServiceTokenRepository>().To<ServiceTokenRepository>();
            Bind<IUserServiceTokenRepository>().To<UserServiceTokenRepository>();
            Bind<IServiceCorsOriginRepository>().To<ServiceCorsOriginRepository>();
            Bind<ICorsOriginRepository>().To<CorsOriginRepository>();

            // REPOSITORY (ReadOnly - Entities)
            Bind(typeof(IReadOnlyRepository<>)).To(typeof(BaseReadOnlyRepository<>));            
            Bind<IUserTokenReadOnlyRepository>().To<UserTokenReadOnlyRepository>();
            Bind<IServiceTokenReadOnlyRepository>().To<ServiceTokenReadOnlyRepository>();
            Bind<IUserServiceTokenReadOnlyRepository>().To<UserServiceTokenReadOnlyRepository>();
            Bind<IServiceCorsOriginReadOnlyRepository>().To<ServiceCorsOriginReadOnlyRepository>();
            Bind<ICorsOriginReadOnlyRepository>().To<CorsOriginReadOnlyRepository>();

            // REPOSITORY (Readonly - Custom)            
            Bind<IUserTokenCustomReadOnlyRepository>().To<UserTokenCustomReadOnlyRepository>();
            Bind<IServiceCorsOriginCustomReadOnlyRepository>().To<ServiceCorsOriginCustomReadOnlyRepository>();

            // DATA CONFIG SERVICE LOCATOR
            Bind<IContextManager>().To<SecurityLayerContextManager>();
            Bind<IUnitOfWork>().To<UnitOfWork>();
        }
    }
}
