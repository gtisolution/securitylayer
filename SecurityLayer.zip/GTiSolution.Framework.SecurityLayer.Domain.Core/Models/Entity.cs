﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentValidation;
using FluentValidation.Results;
using System.ComponentModel.DataAnnotations.Schema;

namespace GTiSolution.Framework.SecurityLayer.Domain.Core.Models
{
    public abstract class Entity<T> : AbstractValidator<T> where T : class 
    {

        [NotMapped]
        public new CascadeMode CascadeMode { get; set; }
        protected ValidationResult ValidationResult;
        public Entity()
        {
            ValidationResult = new ValidationResult();   
        }

        private IList<string> GetValidationResult()
        {
            IList<string> validationResult = new List<string>();
            foreach (var error in ValidationResult.Errors)
                validationResult.Add(error.ErrorMessage);

            return validationResult;
        }

        public abstract bool Valido();

        public IList<string> Validar()
        {
            IList<string> result = new List<string>();
            if (!Valido())
                result = GetValidationResult();

            return result;
        }
    }
}
