using GTiSolution.Framework.SecurityLayer.Domain.Core.Models;
using System;
using System.Collections.Generic;
using FluentValidation;
using System.Web.Security;
using System.Text;
using GTiSolution.Framework.SecurityLayer.Infra.CrossCutting.Security;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace GTiSolution.Framework.SecurityLayer.Domain.Entities
{
    public partial class UserToken : Entity<UserToken>
    { 
        public UserToken()
        {            
            this.UserServiceTokens = new List<UserServiceToken>();
        }

        public UserToken(string userName)
        {            
            UserName = userName;
        }

        public string UserId { get; private set; }
        public string Login { get; private set; }
        public byte[] PasswordHash { get; set; }
        public string UserName { get; private set; }
        
        public virtual ICollection<UserServiceToken> UserServiceTokens { get; private set; }

        public UserToken CriarUsuario(string userName, string password, int qtdeCaracteresLogin)
        {   
            var userId = Guid.NewGuid().ToString();

            byte[] bytesToBeEncrypted = Encoding.UTF8.GetBytes(password);
            byte[] passwordBytes = Encoding.UTF8.GetBytes(userId);
            var usuario = new UserToken
            {
                UserId = userId,
                Login = GerarLogin(qtdeCaracteresLogin),
                PasswordHash = new SecurePasswordHasher().AESEncrypt(bytesToBeEncrypted, passwordBytes),
                UserName = userName
            };

            return usuario;
        }

        public override bool Valido()
        {
            RuleFor(a => a.UserName).NotNull().WithMessage("Nome do usu�rio � obrigat�rio")
                .Length(1, 60).WithMessage("Nome do usu�rio deve ter no m�ximo 60 caracteres");
            ValidationResult = Validate(this);

            return ValidationResult.IsValid;
        }

        private string GerarLogin(int QtdeCaracteresLogin)
        {
            var key = new byte[QtdeCaracteresLogin * 2];
            var keyReplace = new byte[1];
            var replace = Convert.ToBase64String(keyReplace).Substring(0, 1).ToUpper();            
            RNGCryptoServiceProvider.Create().GetBytes(key);
            var login = Convert.ToBase64String(key);
            var result = Regex.Replace(login, "[^0-9a-zA-Z]+", "").Substring(0, QtdeCaracteresLogin).ToUpper();

            return result;
        }
    }
}
