﻿using GTiSolution.Framework.SecurityLayer.Domain.Core.Models;
using System;
using FluentValidation;

namespace GTiSolution.Framework.SecurityLayer.Domain.Entities
{
    public class CorsOrigin : Entity<CorsOrigin>
    {
        public string OriginId { get; private set; }
        public string OriginName { get; private set; }

        public CorsOrigin CriarCorsOrigin(string originName)
        {
            return new CorsOrigin()
            {   
                OriginId = Guid.NewGuid().ToString(),
                OriginName = originName
            };
        }

        public CorsOrigin GerarOrigemAtualizada(string originId, string originName)
        {
            return new CorsOrigin()
            {
                OriginId = originId,
                OriginName = originName
            };
        }

        public override bool Valido()
        {
            RuleFor(a => a.OriginName)
                .NotNull().WithMessage("Nome da origem é obrigatório")
                .Length(1, 256).WithMessage("Nome da origem deve ter no máximo 256 caracteres");

            ValidationResult = Validate(this);

            return ValidationResult.IsValid;
        }
    }
}
