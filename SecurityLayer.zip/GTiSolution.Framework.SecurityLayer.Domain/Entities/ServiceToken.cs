using GTiSolution.Framework.SecurityLayer.Domain.Core.Models;
using System;
using System.Collections.Generic;
using FluentValidation;

namespace GTiSolution.Framework.SecurityLayer.Domain.Entities
{
    public partial class ServiceToken : Entity<ServiceToken>
    {
        public ServiceToken()
        {
            this.UserServiceTokens = new List<UserServiceToken>();
        }

        public ServiceToken(string serviceName)
        {
            ServiceName = serviceName;
        }

        public string ServiceId { get; private set; }
        public string ServiceName { get; private set; }
        public virtual ICollection<UserServiceToken> UserServiceTokens { get; private set; }
        
        public ServiceToken CriarServico(string serviceName)
        {
            var serviceToken = new ServiceToken
            {
                ServiceId = Guid.NewGuid().ToString(),
                ServiceName = serviceName
            };
            return serviceToken;
        }        

        public override bool Valido()
        {
            RuleFor(a => a.ServiceName)
                .NotNull().WithMessage("Nome do servi�o � obrigat�rio")
                .Length(1, 60).WithMessage("Nome do servi�o deve ter no m�ximo 60 caracteres");

            ValidationResult = Validate(this);

            return ValidationResult.IsValid;
        }
    }
}
