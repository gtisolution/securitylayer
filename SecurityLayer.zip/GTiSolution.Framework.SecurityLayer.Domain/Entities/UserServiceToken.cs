using GTiSolution.Framework.SecurityLayer.Domain.Core.Models;
using System;
using System.Collections.Generic;
using FluentValidation;

namespace GTiSolution.Framework.SecurityLayer.Domain.Entities
{
    public partial class UserServiceToken : Entity<UserServiceToken>
    {
        public string Id { get; set; }
        public string UserId { get; private set; }
        public string ServiceId { get; private set; }
        public string ExternalLogin { get; private set; }
        public string Active { get; private set; }
        public virtual ServiceToken ServiceToken { get; private set; }
        public virtual UserToken UserToken { get; private set; }

        public UserServiceToken() { }
        public UserServiceToken(string externalLogin)
        {
            ExternalLogin = externalLogin;
        }

        public void DesativarServico(UserServiceToken userServiceToken)
        {
            userServiceToken.Active = "N";
        }

        public UserServiceToken VincularUsuarioServico(string userId, string serviceId, string externalLogin)
        {
            var usuarioService = new UserServiceToken
            {
                Id = Guid.NewGuid().ToString(),
                ServiceId = serviceId,
                UserId = userId,
                ExternalLogin = externalLogin,
                Active = "S"
            };

            return usuarioService;
        }

        public override bool Valido()
        {
            if (!string.IsNullOrWhiteSpace(ExternalLogin))
                RuleFor(a => a.ExternalLogin).Length(1, 60).WithMessage("Login externo deve ter no m�ximo 60 caracteres");

            ValidationResult = Validate(this);

            return ValidationResult.IsValid;
        }
    }    
}
