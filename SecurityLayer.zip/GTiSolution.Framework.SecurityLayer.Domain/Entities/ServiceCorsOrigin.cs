﻿using GTiSolution.Framework.SecurityLayer.Domain.Core.Models;
using System;
using FluentValidation;

namespace GTiSolution.Framework.SecurityLayer.Domain.Entities
{
    public class ServiceCorsOrigin : Entity<ServiceCorsOrigin>
    {
        public string ServiceId { get; private set; }
        public string OriginId { get; private set; }
        public string Active { get; private set; }

        public ServiceCorsOrigin CriarCorsOrigin(string serviceId, string originId)
        {
            return new ServiceCorsOrigin()
            {
                ServiceId = serviceId,
                OriginId = originId,
                Active = "S"
            };
        }

        public ServiceCorsOrigin DesativarOrigemServico(string serviceId, string originId)
        {
            return new ServiceCorsOrigin
            {
                OriginId = originId,
                ServiceId = serviceId,
                Active = "N"
            };            
        }

        public ServiceCorsOrigin ReativarOrigemServico(string serviceId, string originId)
        {
            return new ServiceCorsOrigin
            {
                OriginId = originId,
                ServiceId = serviceId,
                Active = "S"
            };
        }

        public override bool Valido()
        {
            return true;
        }
    }
}
