﻿using GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.Interfaces.DomainServices;
using GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.Validations;
using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Custom;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Services;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Request;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.Services
{
    public class VinculoUsuarioService : IVinculoUsuarioService
    {
        private readonly IUserTokenReadOnlyRepository _userTokenReadOnlyRepository;
        private readonly IServiceTokenReadOnlyRepository _serviceTokenReadOnlyRepository;
        private readonly IUsuarioDomainService _usuarioDomainService;
        private readonly IServicoDomainService _servicoDomainService;
        private readonly IUsuarioServicoDomainService _usuarioServicoDomainService;
        private readonly IUserServiceTokenRepository _userServiceToken;

        public VinculoUsuarioService(IUserTokenReadOnlyRepository userTokenReadOnlyRepository,
            IServiceTokenReadOnlyRepository serviceTokenReadOnlyRepository,
            IUsuarioDomainService usuarioDomainService,
            IServicoDomainService servicoDomainService,
            IUsuarioServicoDomainService usuarioServicoDomainService,
            IUserServiceTokenRepository userServiceToken)
        {
            _userTokenReadOnlyRepository = userTokenReadOnlyRepository;
            _serviceTokenReadOnlyRepository = serviceTokenReadOnlyRepository;
            _usuarioDomainService = usuarioDomainService;
            _servicoDomainService = servicoDomainService;
            _usuarioServicoDomainService = usuarioServicoDomainService;
            _userServiceToken = userServiceToken;
        }

        #region IVinculoUsuarioService Members

        public ValidationResult VincularUsuarioServico(VinculoUsuarioServicoRequest vinculoUsuarioServicoRequest)
        {
            ValidationResult retorno = new ValidationResult { Mensagem = "Erro ao vincular o usuário ao serviço", Errors = new List<string>() };
            
            // Validar entrada
            if (vinculoUsuarioServicoRequest == null)
            {
                retorno.Mensagem = "Dados para o vínculo devem ser informados";
                return retorno;
            }

            List<string> resultValidation = new List<string>();
            resultValidation.AddRange(vinculoUsuarioServicoRequest.Validar());
            if (resultValidation.Any())
            {   
                retorno.Errors = resultValidation;
                return retorno;
            }

            // Verificar se o serviço existe
            var service = _servicoDomainService.SerivoExiste(vinculoUsuarioServicoRequest.CodigoServico);
            retorno.Errors.AddRange(service.Errors);

            // Verificar se o usuáio existe
            var user = _usuarioDomainService.UsuarioExiste(vinculoUsuarioServicoRequest.Login);            
            retorno.Errors.AddRange(user.Errors);            
            
            // Verificar se o usuário já está vinculado ao serviço
            var userService = _usuarioServicoDomainService.UsuarioJaVinculado(_usuarioDomainService.UserId, _servicoDomainService.ServiceId);
            retorno.Errors.AddRange(userService.Errors);

            // Verificar mensagens de erro
            if (retorno.Errors.Any())
                return retorno;
            
            // Vincular o usuário ao serviço
            var userServiceToken = new UserServiceToken().VincularUsuarioServico(
                _usuarioDomainService.UserId, 
                _servicoDomainService.ServiceId, 
                vinculoUsuarioServicoRequest.LoginExterno);

            _userServiceToken.Adicionar(userServiceToken);
            _userServiceToken.SaveChanges();

            retorno.Mensagem = "Usuário vinculado ao serviço com sucesso";
            return retorno;
        }

        #endregion
    }
}
