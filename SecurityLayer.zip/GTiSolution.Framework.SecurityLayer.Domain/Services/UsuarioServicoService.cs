﻿using GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.Interfaces.DomainServices;
using GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.Validations;
using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Services;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Uow;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Request;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.Services
{
    public class UsuarioServicoService : IUsuarioServicoService
    {        
        private readonly IUsuarioDomainService _usuarioDomainService;
        private readonly IServicoDomainService _servicoDomainService;
        private readonly IUserServiceTokenRepository _userServiceTokenRepository;
        
        private readonly IUnitOfWork _uow;

        public UsuarioServicoService(IUsuarioDomainService usuarioDomainService,
            IServicoDomainService servicoDomainService,
            IUserServiceTokenRepository userServiceTokenRepository,
            IUnitOfWork uow)
        {
            _usuarioDomainService = usuarioDomainService;
            _servicoDomainService = servicoDomainService;
            _userServiceTokenRepository = userServiceTokenRepository;
            _uow = uow;
        }

        #region IUsuarioServicoService Members

        public ValidationResult DesativarUsuario(UsuarioServicoRequest usuarioServicoRequest)
        {
            ValidationResult retorno = new ValidationResult { Mensagem = "Usuário não cadastrado", Errors = new List<string>() };

            // Verificar se o usuário existe            
            var resultValidation = _usuarioDomainService.UsuarioExiste(usuarioServicoRequest.Login);
            retorno.Errors.AddRange(resultValidation.Errors);
            if (retorno.Errors.Any())
                return retorno;            
            
            //Verificar se o serviço existe
            resultValidation = _servicoDomainService.SerivoExiste(usuarioServicoRequest.CodigoServico);
            retorno.Errors.AddRange(resultValidation.Errors);
            if (retorno.Errors.Any())
                return retorno;            

            // Desativar o usuário
            List<UserServiceToken> userServiceToken = _userServiceTokenRepository.Buscar(a => a.UserId == _usuarioDomainService.UserId).ToList();
            userServiceToken.ForEach(service =>
                {   
                    service.DesativarServico(service);
                    _userServiceTokenRepository.Atualizar(service);
                });
            _uow.SaveChanges();

            retorno.Mensagem = "Usuário desativado com sucesso";
            return retorno;
        }

        public ValidationResult DesvicularUsuarioServico(string login, string codigoServico)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
