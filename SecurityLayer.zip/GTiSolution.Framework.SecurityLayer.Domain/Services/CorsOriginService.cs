﻿using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Request;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Uow;

namespace GTiSolution.Framework.SecurityLayer.Domain.Services
{
    public class CorsOriginService : ICorsOriginService
    {
        private readonly ICorsOriginRepository _corsOriginRepository;
        private readonly ICorsOriginReadOnlyRepository _corsOriginReadOnlyRepository;
        private readonly IUnitOfWork _uow;

        public CorsOriginService(ICorsOriginRepository corsOriginRepository,
            ICorsOriginReadOnlyRepository corsOriginReadOnlyRepository,
            IUnitOfWork uow)
        {
            _corsOriginRepository = corsOriginRepository;
            _corsOriginReadOnlyRepository = corsOriginReadOnlyRepository;
            _uow = uow;
        }

        public CorsOriginUpdateResult AtualizarOrigem(CorsOriginRequest request)
        {
            CorsOriginUpdateResult retorno = new CorsOriginUpdateResult { Errors = new List<string>() };

            // Verificar se a origem existe
            var result = _corsOriginReadOnlyRepository.Buscar(a => a.OriginId == request.OriginId);
            if (!result.Any())
            {
                retorno.Mensagem = "Origem informada não existe";
                return retorno;
            }

            var origin = new CorsOrigin().GerarOrigemAtualizada(request.OriginId, request.NewOriginName);
            _corsOriginRepository.Atualizar(origin);
            _uow.SaveChanges();

            retorno.OldOriginName = result.FirstOrDefault().OriginName;
            retorno.NewOriginName = request.NewOriginName;
            retorno.Mensagem = "Origem atualizada com sucesso";
            return retorno;
        }
    }
}
