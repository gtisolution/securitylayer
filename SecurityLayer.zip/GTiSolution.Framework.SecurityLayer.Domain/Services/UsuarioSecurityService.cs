﻿using GTiSolution.Framework.SecurityLayer.Criptografia.Interfaces;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Custom;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Services;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using GTiSolution.Framework.SecurityLayer.Infra.CrossCutting.Security;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.Services
{
    public class UsuarioSecurityService : IUsuarioSecurityService
    {
        private readonly IUserTokenCustomReadOnlyRepository _userTokenCustomReadOnlyRepository;
        private readonly ICriptografiaService _criptografiaService;

        public UsuarioSecurityService(IUserTokenCustomReadOnlyRepository userTokenCustomReadOnlyRepository,
            ICriptografiaService criptografiaService)
        {
            _userTokenCustomReadOnlyRepository = userTokenCustomReadOnlyRepository;
            _criptografiaService = criptografiaService;
        }

        #region IUsuarioSecurityService Members

        public UsuarioSecurityResult ValidarUsuario(string login, string password)
        {
            UsuarioSecurityResult validationResult = new UsuarioSecurityResult();
            try
            {
                // Obter o usuário pelo login
                UsuarioSecurityResult result = _userTokenCustomReadOnlyRepository.ObterUsuarioSecurity(login);
                password = _criptografiaService.DescriptografarTexto(password);                

                // Validar o usuário
                validationResult = Validar(result, password);
                if (!string.IsNullOrWhiteSpace(validationResult.Mensagem))
                    return validationResult;
            }
            catch (FormatException)
            {
                validationResult.Mensagem = "Usuário ou senha inválidos";
            }
            catch (Exception)
            {
                validationResult.Mensagem = "Erro 1000";
            }            
            return validationResult;
        }

        #endregion

        private UsuarioSecurityResult Validar(UsuarioSecurityResult usuarioSecurityResult, string password)
        {  
            if (usuarioSecurityResult == null)
            {
                usuarioSecurityResult = new UsuarioSecurityResult();
                usuarioSecurityResult.Mensagem = "Usuario ou senha inválidos";
                return usuarioSecurityResult;
            }

            // Comparação do hash da senha
            byte[] bytesToBeEncrypted = Encoding.UTF8.GetBytes(password);
            byte[] passwordBytes = Encoding.UTF8.GetBytes(usuarioSecurityResult.CodigoUsuario);
            var PasswordHash = new SecurePasswordHasher().AESEncrypt(bytesToBeEncrypted, passwordBytes);

            if (!HashCompare.ByteArrayCompare(usuarioSecurityResult.PasswordHash, PasswordHash))
                usuarioSecurityResult.Mensagem = "Usuario ou senha inválidos";
            
            if (!usuarioSecurityResult.Servicos.Any(a => a.ServicoAtivo == "S"))
                usuarioSecurityResult.Mensagem = "Login está desativado";

            return usuarioSecurityResult;
        }
        
        
    }
}
