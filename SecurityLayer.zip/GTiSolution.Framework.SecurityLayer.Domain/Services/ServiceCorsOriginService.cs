﻿using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Request;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Uow;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Custom;

namespace GTiSolution.Framework.SecurityLayer.Domain.Services
{
    public class ServiceCorsOriginService : IServiceCorsOriginService
    {
        private readonly IServiceCorsOriginRepository _serviceCorsOriginRepository;        
        private readonly ICorsOriginRepository _corsOriginRepository;
        private readonly IServiceTokenReadOnlyRepository _serviceTokenReadOnlyRepository;
        private readonly ICorsOriginReadOnlyRepository _corsOriginReadOnlyRepository;
        private readonly IServiceCorsOriginReadOnlyRepository _serviceCorsOriginReadOnlyRepository;
        private readonly IServiceCorsOriginCustomReadOnlyRepository _serviceCorsOriginCustomReadOnlyRepository;
        private readonly IUnitOfWork _uow;

        public ServiceCorsOriginService(IServiceCorsOriginRepository serviceCorsOriginRepository,
            ICorsOriginRepository corsOriginRepository,
            IServiceTokenReadOnlyRepository serviceTokenReadOnlyRepository,
            ICorsOriginReadOnlyRepository corsOriginReadOnlyRepository,
            IServiceCorsOriginReadOnlyRepository serviceCorsOriginReadOnlyRepository,
            IServiceCorsOriginCustomReadOnlyRepository serviceCorsOriginCustomReadOnlyRepository,
            IUnitOfWork uow
            )
        {
            _serviceCorsOriginRepository = serviceCorsOriginRepository;            
            _corsOriginRepository = corsOriginRepository;
            _serviceTokenReadOnlyRepository = serviceTokenReadOnlyRepository;
            _corsOriginReadOnlyRepository = corsOriginReadOnlyRepository;
            _serviceCorsOriginReadOnlyRepository = serviceCorsOriginReadOnlyRepository;
            _serviceCorsOriginCustomReadOnlyRepository = serviceCorsOriginCustomReadOnlyRepository;
            _uow = uow;
        }

        public ServicoCorsOriginResult DesativarOrigemServico(ServiceCorsOriginUpdateRequest serviceCorsOriginUpdateRequest)
        {
            ServicoCorsOriginResult retorno = new ServicoCorsOriginResult {Errors = new List<string>() };
            
            // Validar se o serviço e origem informados existem
            retorno = Validar(serviceCorsOriginUpdateRequest, retorno);
            if (!string.IsNullOrEmpty(retorno.Mensagem))
                return retorno;

            ServiceCorsOrigin origin = new ServiceCorsOrigin().DesativarOrigemServico(serviceCorsOriginUpdateRequest.ServiceId, serviceCorsOriginUpdateRequest.OriginId);
            _serviceCorsOriginRepository.Atualizar(origin);
            _uow.SaveChanges();

            retorno.OriginId = origin.OriginId;
            retorno.Active = origin.Active;
            retorno.Mensagem = "Origem desativada com sucesso";
            return retorno;
        }

        public ServicoCorsOriginResult ReativarOrigemServico(ServiceCorsOriginUpdateRequest serviceCorsOriginUpdateRequest)
        {
            ServicoCorsOriginResult retorno = new ServicoCorsOriginResult { Errors = new List<string>() };

            // Validar se o serviço e origem informados existem
            retorno = Validar(serviceCorsOriginUpdateRequest, retorno);
            if (!string.IsNullOrEmpty(retorno.Mensagem))
                return retorno;
            
            ServiceCorsOrigin origin = new ServiceCorsOrigin().ReativarOrigemServico(serviceCorsOriginUpdateRequest.ServiceId, serviceCorsOriginUpdateRequest.OriginId);
            _serviceCorsOriginRepository.Atualizar(origin);
            _uow.SaveChanges();

            retorno.OriginId = origin.OriginId;
            retorno.Active = origin.Active;
            retorno.Mensagem = "Origem reativada com sucesso";
            return retorno;
        }

        public ServicoCorsOriginResult NovaOrigemServico(ServiceCorsOriginRequest corsOriginServiceRequest)
        {
            ServicoCorsOriginResult retorno = new ServicoCorsOriginResult { Errors = new List<string>() };
            CorsOrigin origin = new CorsOrigin();

            // Verificar se o serviço informado existe         
            var service = _serviceTokenReadOnlyRepository.Buscar(a => a.ServiceId == corsOriginServiceRequest.ServiceId).ToList();
            retorno = ValidarServico(retorno, service);
            if (!string.IsNullOrWhiteSpace(retorno.Mensagem))
                return retorno;

            // Verificar se a origem já está vinculada há um servico
            var resultOrigemServico = _serviceCorsOriginCustomReadOnlyRepository.ListarOrigemServicoPorServiceId(corsOriginServiceRequest.ServiceId);
            var result = resultOrigemServico.FirstOrDefault(a => a.OriginName == corsOriginServiceRequest.OriginName);
            if (result != null)
            //if (resultOrigemServico.Any(a => a.OriginName.Equals(corsOriginServiceRequest.OriginName)))
            {
                if (result.Active.Equals("S"))
                    retorno.Mensagem = "Origem já está ativada para este serviço";
                else
                    retorno.Mensagem = "Origem está vinculada a este serviço, porém está desativada";                
                retorno.Active = result.Active;
                retorno.OriginId = result.OriginId;
                return retorno;
            }

            // Verificar se a origem informada existe, para poder criar uma nova caso não exista
            var originResult = _corsOriginReadOnlyRepository.Buscar(a => a.OriginName == corsOriginServiceRequest.OriginName);
            bool criarOrigem = false;
            string originId = string.Empty;
            if (!originResult.Any())
            {
                origin = new CorsOrigin().CriarCorsOrigin(corsOriginServiceRequest.OriginName);
                originId = origin.OriginId;
                criarOrigem = true;
            }
            else
                originId = originResult.First().OriginId;
            
            // Criar nova instância de Serviço Origem
            var novoServicoOrigem = new ServiceCorsOrigin().CriarCorsOrigin(service.First().ServiceId, originId);
            var resultValidation = novoServicoOrigem.Validar();
            if (resultValidation.Any())
            {
                retorno.Mensagem = "Erro ao cadastrar a origem.";
                retorno.Errors.AddRange(resultValidation);

                return retorno;
            }

            _uow.BeginTransaction();
            if (criarOrigem)
                _corsOriginRepository.Adicionar(origin);
            _serviceCorsOriginRepository.Adicionar(novoServicoOrigem);
            _uow.SaveChanges();

            retorno.Active = novoServicoOrigem.Active;
            retorno.OriginId = novoServicoOrigem.OriginId;

            retorno.Mensagem = "Origem criada com sucesso";
            return retorno;
        }       

        private ServicoCorsOriginResult ValidarServico(ServicoCorsOriginResult validator, List<ServiceToken> service)
        {
            // Verificar se o serviço informado existe
            if (!service.Any())
                validator.Mensagem = "Serviço informado não existe";

            return validator;
        }

        private ServicoCorsOriginResult ValidarOrigem(ServicoCorsOriginResult validator, string originId)
        {
            var result = _corsOriginReadOnlyRepository.Buscar(a => a.OriginId == originId);
            if (!result.Any())
                validator.Mensagem = "Origem informada não existe";

            return validator;
        }        

        private ServicoCorsOriginResult Validar(ServiceCorsOriginUpdateRequest serviceCorsOriginUpdateRequest, ServicoCorsOriginResult servicoCorsOriginResult)
        {
            // Verificar se o serviço informado existe       
            var service = _serviceTokenReadOnlyRepository.Buscar(a => a.ServiceId == serviceCorsOriginUpdateRequest.ServiceId).ToList();
            servicoCorsOriginResult = ValidarServico(servicoCorsOriginResult, service);
            if (!string.IsNullOrWhiteSpace(servicoCorsOriginResult.Mensagem))
                return servicoCorsOriginResult;

            // Verificar se a origem existe
            servicoCorsOriginResult = ValidarOrigem(servicoCorsOriginResult, serviceCorsOriginUpdateRequest.OriginId);
            if (!string.IsNullOrWhiteSpace(servicoCorsOriginResult.Mensagem))
                return servicoCorsOriginResult;

            return servicoCorsOriginResult;
        }
    }
}
