﻿using GTiSolution.Framework.SecurityLayer.Criptografia.Interfaces;
using GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.Validations;
using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Custom;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Services;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Uow;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Request;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using GTiSolution.Framework.SecurityLayer.Infra.CrossCutting.Security;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Security;

namespace GTiSolution.Framework.SecurityLayer.Domain.Services
{
    public class UsuarioService : IUsuarioService
    {
        private readonly IUserTokenRepository _userTokenRepository;
        private readonly IServiceTokenRepository _serviceToken;
        private readonly IUserServiceTokenRepository _userServiceToken;
        private readonly IUserTokenCustomReadOnlyRepository _userTokenCustomReadOnlyRepository;
        private readonly IServiceTokenReadOnlyRepository _serviceTokenReadOnlyRepository;
        private readonly ICriptografiaService _criptografia;
        private readonly IUnitOfWork _uow;

        public UsuarioService(IUserTokenRepository userTokenRepository,
            IServiceTokenRepository serviceToken,
            IUserServiceTokenRepository userServiceToken,
            IUserTokenCustomReadOnlyRepository userTokenCustomReadOnlyRepository,
            IServiceTokenReadOnlyRepository serviceTokenReadOnlyRepository,
            ICriptografiaService criptografia,
            IUnitOfWork uow)
        {
            _userTokenRepository = userTokenRepository;
            _serviceToken = serviceToken;
            _userServiceToken = userServiceToken;
            _userTokenCustomReadOnlyRepository = userTokenCustomReadOnlyRepository;
            _serviceTokenReadOnlyRepository = serviceTokenReadOnlyRepository;
            _criptografia = criptografia;
            _uow = uow;
        }

        #region IUsuarioService Members

        public NovoUsuarioResult CriarUsuario(NovoUsuarioRequest user)
        {
            bool NovoServico = false;
            NovoUsuarioResult retorno = new NovoUsuarioResult { Mensagem = "Usuário criado com sucesso", Errors = new List<string>() };

            if (user == null)
            {
                retorno.Mensagem = "Dados do usuário devem ser informados";
                return retorno;
            }

            // Validar requisição                        
            UserToken userToken = new UserToken(user.NomeUsuario);
            ServiceToken serviceToken = new ServiceToken(user.NomeServico);
            UserServiceToken userServiceToken = new UserServiceToken(user.LoginExterno);

            var resultValidation = Validar(user, userToken, serviceToken, userServiceToken);
            if (resultValidation.Any())
            {
                retorno.Mensagem = "Erro ao cadastrar o usuário.";
                retorno.Errors.AddRange(resultValidation);

                return retorno;
            }

            var comprimentoSenha = int.Parse(ConfigurationManager.AppSettings["ComprimentoSenha"]);
            var qtdeNaoAlfaNumerico = int.Parse(ConfigurationManager.AppSettings["QtdeNumerosNaSenha"]);
            var qtdeCaracteresLogin = int.Parse(ConfigurationManager.AppSettings["QtdeCaracteresLogin"]);
            var encryptioKey = ConfigurationManager.AppSettings["EncryptionKey"];

            // Gerar senha forte
            var password = Membership.GeneratePassword(comprimentoSenha, qtdeNaoAlfaNumerico);

            // Criar novo usuário    
            userToken = userToken.CriarUsuario(user.NomeUsuario, password, qtdeCaracteresLogin);            
            retorno.Login = userToken.Login;
            //using (SecurePasswordHasher hasher = new SecurePasswordHasher())
            //{
            //    retorno.Senha = hasher.EncryptText(password, encryptioKey);
            //}
            retorno.Senha = _criptografia.CriptografarTexto(password);

            // Identificar serviço
            serviceToken = _serviceTokenReadOnlyRepository.Buscar(a => a.ServiceName == user.NomeServico).FirstOrDefault();
            if (serviceToken == null)
            {
                serviceToken = new ServiceToken().CriarServico(user.NomeServico);
                NovoServico = true;
            }

            // Vicular usuário so serviço
            userServiceToken = userServiceToken.VincularUsuarioServico(userToken.UserId, serviceToken.ServiceId, _criptografia.CriptografarTexto(user.LoginExterno));

            _uow.BeginTransaction();

            // Persitir dados
            if (NovoServico)
                _serviceToken.Adicionar(serviceToken);                        
            _userTokenRepository.Adicionar(userToken);            
            _userServiceToken.Adicionar(userServiceToken);

            _uow.SaveChanges();

            return retorno;
        }

        #endregion

        private IList<string> Validar(NovoUsuarioRequest user, UserToken userToken, ServiceToken serviceToken, UserServiceToken userServiceToken)
        {
            List<string> result = new List<string>();
            result.AddRange(userToken.Validar());
            result.AddRange(serviceToken.Validar());
            result.AddRange(userServiceToken.Validar());

            var validacaoWebConfig = ValidarWebConfig();
            if (!string.IsNullOrWhiteSpace(validacaoWebConfig))
                result.Add(validacaoWebConfig);

            return result;
        }

        private string ValidarWebConfig()
        {
            if (ConfigurationManager.AppSettings["ComprimentoSenha"] == null)
                return "Configuração 'ComprimentoSenha' não encontrada";

            if (ConfigurationManager.AppSettings["QtdeNumerosNaSenha"] == null)
                return "Configuração 'QtdeNumerosNaSenha' não encontrada";

            if (ConfigurationManager.AppSettings["QtdeCaracteresLogin"] == null)
                return "Configuração 'QtdeCaracteresLogin' não encontrada";

            return string.Empty;
        }
    }
}
