﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result
{
    public class OrigemServicoCustomResult
    {
        public string ServiceId { get; set; }
        public string OriginId { get; set; }
        public string OriginName { get; set; }
        public string Active { get; set; }
    }
}
