﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result
{
    public class ServicoCorsOriginResult : BaseResult
    {
        public string OriginId { get; set; }
        public string Active { get; set; }
    }
}
