﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result
{
    public class UsuarioSecurityResult
    {
        public UsuarioSecurityResult()
        {
            Servicos = new List<UsuarioServicoResult>();
        }
        public string Mensagem { get; set; }
        public string CodigoUsuario { get; set; }   
        public string Senha { get; set; }
        public byte[] PasswordHash { get; set; }
        public List<UsuarioServicoResult> Servicos { get; set; }
    }
}
