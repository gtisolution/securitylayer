﻿using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Request
{
    public class ServiceCorsOriginRequest
    {
        public string ServiceId { get; set; }
        public string OriginName { get; set; }
    }
}
