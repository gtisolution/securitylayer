﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Request.Validation
{
    public class VinculoUsuarioServicoRequestValidator : AbstractValidator<VinculoUsuarioServicoRequest>
    {
        public VinculoUsuarioServicoRequestValidator()
        {
            RuleFor(a => a.Login).NotNull().WithMessage("Login é obrigatório");
            RuleFor(a => a.CodigoServico)
                .NotNull().WithMessage("Nome do serviço é obrigatório");
        }
    }
}
