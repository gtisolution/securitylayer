﻿using GTiSolution.Framework.SecurityLayer.Domain.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentValidation;
using FluentValidation.Attributes;

namespace GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Request
{
    
    public class VinculoUsuarioServicoRequest : Entity<VinculoUsuarioServicoRequest>
    {
        public string Login { get; set; }
        public string CodigoServico { get; set; }
        public string LoginExterno { get; set; }

        public override bool Valido()
        {
            RuleFor(a => a.Login).NotNull().WithMessage("Login é obrigatório")
                .Length(1, 32).WithMessage("Login deve ter no máximo 32 caracteres");
            RuleFor(a => a.CodigoServico)
                .NotNull().WithMessage("Nome do serviço é obrigatório");

            if (!string.IsNullOrWhiteSpace(LoginExterno))
                RuleFor(a => a.LoginExterno).Length(1, 60).WithMessage("Login externo deve ter no máximo 60 caracteres");

            ValidationResult = Validate(this);
            return ValidationResult.IsValid;
        }
    }
}
