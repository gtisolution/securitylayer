﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Request
{
    public class NovoUsuarioRequest
    {                
        public string NomeUsuario { get; set; }        
        public string NomeServico { get; set; }        
        public string LoginExterno { get; set; }

    }
}
