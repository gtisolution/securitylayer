﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly
{
    public interface IReadOnlyRepository<TEntity> : IDisposable where TEntity : class
    {
        IEnumerable<TEntity> ListarTodos();
        IEnumerable<TEntity> Buscar(Expression<Func<TEntity, bool>> predicate);
    }
}
