﻿using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Entities
{
    public interface IUserServiceTokenReadOnlyRepository : IReadOnlyRepository<UserServiceToken>
    {
    }
}
