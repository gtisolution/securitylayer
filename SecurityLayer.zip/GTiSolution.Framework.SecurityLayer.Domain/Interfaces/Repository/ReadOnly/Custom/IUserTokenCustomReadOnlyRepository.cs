﻿using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Custom
{
    public interface IUserTokenCustomReadOnlyRepository
    {
        UsuarioSecurityResult ObterUsuarioSecurity(string login);
        UsuarioResult ObterUsuario(string login);
        IEnumerable<UsuarioResult> ListarUsuarios();

    }
}
