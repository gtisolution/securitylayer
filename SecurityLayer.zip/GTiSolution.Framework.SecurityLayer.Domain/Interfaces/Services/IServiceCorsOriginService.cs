﻿using GTiSolution.Framework.SecurityLayer.Domain.Entities;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Request;
using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Services
{
    public interface IServiceCorsOriginService
    {
        ServicoCorsOriginResult NovaOrigemServico(ServiceCorsOriginRequest corsOriginServiceRequest);
        ServicoCorsOriginResult DesativarOrigemServico(ServiceCorsOriginUpdateRequest serviceCorsOriginUpdateRequest);
        ServicoCorsOriginResult ReativarOrigemServico(ServiceCorsOriginUpdateRequest serviceCorsOriginUpdateRequest);
    }
}
