﻿using GTiSolution.Framework.SecurityLayer.Domain.TransferObject.Result;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Services
{
    public interface IUsuarioSecurityService
    {
        UsuarioSecurityResult ValidarUsuario(string login, string password);
    }
}
