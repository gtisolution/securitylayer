﻿using GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.Validations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.Interfaces.DomainServices
{
    public interface IUsuarioServicoDomainService
    {
        ValidationResult UsuarioJaVinculado(string codigoUsuario, string codigoServico);
        
    }
}
