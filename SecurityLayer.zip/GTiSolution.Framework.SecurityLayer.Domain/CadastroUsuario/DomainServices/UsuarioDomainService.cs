﻿using GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.Interfaces.DomainServices;
using GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.Validations;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.DomainServices
{
    public class UsuarioDomainService : BaseValidationDomainService, IUsuarioDomainService
    {
        private readonly IUserTokenReadOnlyRepository _userTokenReadOnlyRepository;

        public string UserId { get; set; }

        public UsuarioDomainService(IUserTokenReadOnlyRepository userTokenReadOnlyRepository) 
            : base()
        {
            _userTokenReadOnlyRepository = userTokenReadOnlyRepository;
        }

        #region IUsuarioDomainService Members

        public ValidationResult UsuarioExiste(string login)
        {
            var user = _userTokenReadOnlyRepository.Buscar(a => a.Login == login);
            if (!user.Any())
                _validationResult.Errors.Add("Usuário não encontrado");
            else
                UserId = user.FirstOrDefault().UserId;

            return _validationResult;
        }

        #endregion
    }
}
