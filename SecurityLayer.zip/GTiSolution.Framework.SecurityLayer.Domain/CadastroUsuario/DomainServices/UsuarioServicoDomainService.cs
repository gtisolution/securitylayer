﻿using GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.Interfaces.DomainServices;
using GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.Validations;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.DomainServices
{
    public class UsuarioServicoDomainService : BaseValidationDomainService, IUsuarioServicoDomainService
    {
        private readonly IUserServiceTokenReadOnlyRepository _userServiceTokenReadOnlyRepository;

        public UsuarioServicoDomainService(IUserServiceTokenReadOnlyRepository userServiceTokenReadOnlyRepository)
            : base()
        {
            _userServiceTokenReadOnlyRepository = userServiceTokenReadOnlyRepository;
        }

        #region IUsuarioServicoDomainService Members

        public ValidationResult UsuarioJaVinculado(string codigoUsuario, string codigoServico) 
            
        {
            if (!string.IsNullOrWhiteSpace(codigoUsuario) && !string.IsNullOrWhiteSpace(codigoServico))
            {
                var userService = _userServiceTokenReadOnlyRepository.Buscar(a => a.UserId == codigoUsuario && a.ServiceId == codigoServico);
                if (userService.Any())
                    _validationResult.Errors.Add("Usuário já está vinculado a este serviço");
            }
            return _validationResult;
        }

        #endregion
    }
}
