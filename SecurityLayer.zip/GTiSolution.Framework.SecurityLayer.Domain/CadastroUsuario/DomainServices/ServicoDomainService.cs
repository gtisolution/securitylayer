﻿using GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.Interfaces.DomainServices;
using GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.Validations;
using GTiSolution.Framework.SecurityLayer.Domain.Interfaces.Repository.ReadOnly.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.DomainServices
{
    public class ServicoDomainService : BaseValidationDomainService, IServicoDomainService
    {
        private readonly IServiceTokenReadOnlyRepository _serviceTokenReadOnlyRepository;

        public string ServiceId { get; set; }

        public ServicoDomainService(IServiceTokenReadOnlyRepository serviceTokenReadOnlyRepository) 
            : base()
        {
            _serviceTokenReadOnlyRepository = serviceTokenReadOnlyRepository;
        }

        #region IServicoDomainService Members

        public ValidationResult SerivoExiste(string codigoServico)
        {
            var service = _serviceTokenReadOnlyRepository.Buscar(a => a.ServiceId == codigoServico);
            if (!service.Any())
                _validationResult.Errors.Add("Serviço não encontrado");
            else
                ServiceId = service.FirstOrDefault().ServiceId;

            return _validationResult;
        }

        #endregion
    }
}
