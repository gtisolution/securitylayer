﻿using GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.Validations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Domain.CadastroUsuario.DomainServices
{
    public abstract class BaseValidationDomainService
    {
        protected ValidationResult _validationResult;

        public BaseValidationDomainService()
        {
            _validationResult = new ValidationResult();
            _validationResult.Errors = new List<string>();
        }
    }
}
