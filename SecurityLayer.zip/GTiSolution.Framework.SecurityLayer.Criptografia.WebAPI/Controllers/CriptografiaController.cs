﻿using GTiSolution.Framework.SecurityLayer.Infra.CrossCutting.Security;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace GTiSolution.Framework.SecurityLayer.Criptografia.WebAPI.Controllers
{   
    [RoutePrefix("api/seguranca/criptografia")]
    public class CriptografiaController : ApiController
    {
        private static string _encryptioKey = ConfigurationManager.AppSettings["EncryptionKey"];
        private CriptografiaResult _resultCriptografia;

        public CriptografiaController()
        {
            _resultCriptografia = new CriptografiaResult();
        }

        [HttpPost]
        [Route("criptografar-texto")]
        public IHttpActionResult Criptografar(CriptografiaRequest criptografiaRequest)
        {   
            using (SecurePasswordHasher hasher = new SecurePasswordHasher())
            {
                _resultCriptografia.Result = hasher.EncryptText(criptografiaRequest.Texto, _encryptioKey);
            }
            return Ok(_resultCriptografia);
        }

        [Route("descriptografar-texto")]
        [HttpPost]
        public IHttpActionResult Descriptografar(CriptografiaRequest criptografiaRequest)
        {   
            using (SecurePasswordHasher hasher = new SecurePasswordHasher())
            {
                _resultCriptografia.Result = hasher.DecryptText(criptografiaRequest.Texto, _encryptioKey);
            }

            return Ok(_resultCriptografia);
        }
    }
}
