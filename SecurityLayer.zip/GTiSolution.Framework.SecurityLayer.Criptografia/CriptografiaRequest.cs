﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Criptografia
{
    public class CriptografiaRequest
    {        
        [Required(ErrorMessage="Texto para criptogrfia/descriptografia é obrigatório")]
        public string Texto { get; set; }
    }
}
