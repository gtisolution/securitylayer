﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Criptografia.Interfaces
{
    public interface ICriptografiaService
    {
        string CriptografarTexto(string value);
        string DescriptografarTexto(string value);
    }
}
