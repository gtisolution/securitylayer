﻿using GTiSolution.Framework.SecurityLayer.Criptografia.Interfaces;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTiSolution.Framework.SecurityLayer.Criptografia.Services
{
    public class CriptografiaService : ICriptografiaService
    {
        private static string _urlPadrao = ConfigurationManager.AppSettings["ApiCriptografia"];
        private static Method _metodo = Method.POST;

        #region ICriptografiaService Members

        public string CriptografarTexto(string value)
        {
            return Executar(_urlPadrao, "/criptografar-texto", _metodo, value);
        }

        public string DescriptografarTexto(string value)
        {
            return Executar(_urlPadrao, "/descriptografar-texto", _metodo, value);
        }

        #endregion

        private string Executar(string url, string resource, Method method, string value)
        {
            var client = new RestClient(url);
            var request = new RestRequest(resource, method);
            request.AddJsonBody(new CriptografiaRequest { Texto = value });

            var result = client.Execute<CriptografiaResult>(request);
            return result.Data.Result;
        }

    }
}
